package com.example.projecto_integrador.model;

public enum UsuarioRole {
    ROLE_USER, ROLE_ADMIN
}
