package com.example.projecto_integrador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectoIntegradorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectoIntegradorApplication.class, args);
	}

}
