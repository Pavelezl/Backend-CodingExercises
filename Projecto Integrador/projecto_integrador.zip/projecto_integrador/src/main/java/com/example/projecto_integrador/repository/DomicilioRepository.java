package com.example.projecto_integrador.repository;


import com.example.projecto_integrador.model.Domicilio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DomicilioRepository extends JpaRepository<Domicilio, Long> {

}

