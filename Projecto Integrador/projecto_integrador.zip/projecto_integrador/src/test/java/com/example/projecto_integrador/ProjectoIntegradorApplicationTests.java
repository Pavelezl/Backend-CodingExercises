package com.example.projecto_integrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectoIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
